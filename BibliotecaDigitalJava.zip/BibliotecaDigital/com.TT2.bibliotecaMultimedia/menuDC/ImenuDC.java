package menuDC;
import java.util.List;

public interface ImenuDC {
	
	    public List<menuDC> findAll();

}
