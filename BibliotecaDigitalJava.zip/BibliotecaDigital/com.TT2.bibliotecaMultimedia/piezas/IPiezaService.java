package piezas;
import java.util.List;
import usuarios.Usuario;

public interface IPiezaService
{
    public List<Pieza> findAll_piezas();
    
   
    
}
