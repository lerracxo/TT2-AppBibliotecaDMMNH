package archivos;

import piezas.Multimedia;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service("SubeArchivoService")
@RemotingDestination(channels = {"my-amf"})
public class SubeArchivo {
	
	//change this to the desired path you wish the files to be uploaded
	// Direcci�n del servidor para la multimedia
	private String FilePath = "/Users/omar/Documents/Servidores/apache-tomcat-6.0.35/webapps/ROOT/multimedia/";
	
	/*
	 * M�todo que realiza la escritura del archivo en el servidor de archivos
	 * */
	@RemotingInclude
	public Boolean escribeArchivo(String nombre_archivo, byte[] data) {
		try{
			System.out.println("Peticion recibida: "+nombre_archivo+" len data: "+data.length);
			
			//create the dir that we will store files
			File dir = new File(FilePath);
			dir.mkdirs();
			
			File file = new File(FilePath +nombre_archivo);
			FileOutputStream output = new FileOutputStream(file);
			output.write(data);
			output.close();
			
			//System.out.println("Ruta absoluta del archibo: "+file.getAbsolutePath());
		}
		catch(FileNotFoundException e){
			System.out.println("Error: "+e.getMessage());
			return false;
		}
		catch(IOException e){
			System.out.println("Error: "+e.getMessage());
			return false;
		}
	
		return true;
	}
	
	public String extensionArchivo(String nombre_archivo){
		
		String extension="";

		int i = nombre_archivo.lastIndexOf('.');
		if (i > 0) {
		    extension = nombre_archivo.substring(i+1);
		}
	
		return "."+extension;
		
	}
	@RemotingInclude
	public byte[] bajaArchivo(Multimedia multimedia){
		
		try{
			File file = new File(FilePath+multimedia.getNombre_archivo());
			FileInputStream input = new FileInputStream(file);
			byte[] archivo = new byte[(int) file.length()];
			input.read(archivo);
			input.close();
		
			return archivo;
		
		}catch(FileNotFoundException e){
			System.out.println("Error: "+e.getMessage());
			return null;
		}
		catch(IOException e){
			System.out.println("Error: "+e.getMessage());
			return null;
		}
	}
	
	
	
}
