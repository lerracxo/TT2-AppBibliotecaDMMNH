package epocas;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import usuarios.Usuario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.flex.remoting.RemotingExclude;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Service;

import bitacora.Bitacora;
import bitacora.BitacoraService;


 @Service("EpocaService")
 @RemotingDestination(channels={"my-amf"})
public class EpocaSevice implements IEpocaService {
	 
	    private static DataSource dataSourceDCpro;
	    
	    private SimpleJdbcTemplate simpleJdbcTemplate;
	    
	    private SimpleJdbcInsert  insertEpoca;
	    private BitacoraService bitacora = new BitacoraService();

		public DataSource getDataSource(){
			   return dataSourceDCpro;
		   }
		@Autowired
		public void setDataSource(DataSource dataSourceDCpro){

			this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSourceDCpro);
	        this.insertEpoca = new SimpleJdbcInsert(dataSourceDCpro).withTableName("cat_epoca").usingGeneratedKeyColumns("id_epoca");
	        
	       }

		/*
		 * M�todo que retorna una lista de todos los autores disponibles en el sistema
		 * */
		@RemotingInclude
		public List<Epoca> findAll(){
			String sql_txt = "SELECT id_epoca, nombre, desc_epoca, anio FROM cat_epoca";
			
			List<Epoca> lista = new ArrayList<Epoca>();
			
			List<Map<String, Object>> rows = simpleJdbcTemplate.queryForList(sql_txt);
			
			for (Map<String, Object> row : rows){ 
				lista.add(new Epoca(
						((Integer)row.get("id_epoca")),
						((String)row.get("nombre")),
						((String)row.get("desc_epoca")),
						((String)row.get("fecha"))
						));
			}
			
			System.out.println("lista Autor: "+lista);
			return lista;
		}
		/*
		 * M�todo que realiza el registro de un autor
		 * */
		public Boolean registra(Epoca epoca){
			// Realiza la parametrizaci�n del objeto
			 Map<String, Object> parameters = new HashMap<String, Object>();
		        parameters.put("nombre", epoca.getNombre());
		        parameters.put("desc_epoca",epoca.getDesc_epoca());
		        parameters.put("fecha",epoca.getAnio());
		    // Realiza la inserci�n en la base de datos.
			Number id_autor = insertEpoca.executeAndReturnKey(parameters);
			
			// Registra el evento en la bitacora
			bitacora.registra_eventoBitacora(new Bitacora(0,"Archivo","Registro de epoca: "+epoca.getNombre()));
			    
			return true;
		}
		
		/*
		 *  M�todo que realiza la eliminaci�n de un autor
		 * */
		@RemotingInclude
		public Boolean elimina(Epoca epoca){
			String sql_txt = "DELTE FROM cat_epoca WHERE id_epoca = ?";
			
			int result = simpleJdbcTemplate.update(sql_txt, new Object[] {epoca.getId_epoca()});
			
			// Registra el evento en la bitacora
			bitacora.registra_eventoBitacora(new Bitacora(0,"Archivo","Eliminaci�n de epoca: "+epoca.getNombre()));
						
			return true;
		}
		
		@RemotingInclude
		public Boolean modifica(Epoca epoca){
			String sql_txt = "UPDATE cat_epoca SET nombre= ?, desc_epoca = ?, anio = ? " +
					" WHERE id_epoca = ?";
			
			int result = simpleJdbcTemplate.update(sql_txt, new Object[] {
					epoca.getNombre(),
					epoca.getDesc_epoca(),
					epoca.getAnio(),
					epoca.getId_epoca()
			});
			
			// Registra el evento en la bitacora
			bitacora.registra_eventoBitacora(new Bitacora(0,"Archivo","Modificaci�n de epoca: "+epoca.getNombre()));
						
			return true;
		}
		
}